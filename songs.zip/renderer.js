const playlist = document.getElementById('playlist');
const player = document.getElementById('player');

let currentPlaylist = [];
let currentIndex = -1;

async function selectFolder() {
  const folderPath = await window.electronAPI.selectFolder();
  if (!folderPath) return;

  const mp3Files = await window.electronAPI.getMp3Files(folderPath);
  if (!mp3Files || mp3Files.length === 0) {
    playlist.innerHTML = '<li class="list-group-item">No MP3 files found.</li>';
    return;
  }

  currentPlaylist = mp3Files;
  loadPlaylist();
}



function loadPlaylist() {
  playlist.innerHTML = '';
  currentPlaylist.forEach((track, index) => {
    const li = document.createElement('li');
    li.textContent = track.name;
    li.className = 'list-group-item';
    li.onclick = () => playTrack(index);
    playlist.appendChild(li);
  });
}

function playTrack(index) {
  if (!currentPlaylist[index]) return;
  currentIndex = index;
  const track = currentPlaylist[index];

  // Encode URI for cross-platform compatibility
player.src = encodeURI(`file://${track.path.replace(/\\/g, '/')}`);

  player.play();
  highlightActive(index);
}

function highlightActive(index) {
  Array.from(playlist.children).forEach((li, i) => {
    li.classList.toggle('active', i === index);
  });
}

function playPrevious() {
  if (currentIndex > 0) {
    playTrack(currentIndex - 1);
  }
}

function playNext() {
  if (currentIndex < currentPlaylist.length - 1) {
    playTrack(currentIndex + 1);
  }
}

player.addEventListener('ended', playNext);

// Expose globally if buttons are still inline in HTML
window.selectFolder = selectFolder;
window.playPrevious = playPrevious;
window.playNext = playNext;
