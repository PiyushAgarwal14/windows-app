const playlist = document.getElementById('playlist');
const player = document.getElementById('player');

let currentPlaylist = [];
let currentIndex = -1;

// 1. Select and load folder containing mp3 files
async function selectFolder() {
  const folderPath = await window.electronAPI.selectFolder();
  if (!folderPath) return;

  const mp3Files = await window.electronAPI.getMp3Files(folderPath);
  if (!mp3Files || mp3Files.length === 0) {
    playlist.innerHTML = '<li class="list-group-item">No MP3 files found.</li>';
    return;
  }

  currentPlaylist = mp3Files;
  currentIndex = -1;
  loadPlaylist();
}

// 2. Load playlist into the UI
function loadPlaylist() {
  playlist.innerHTML = '';
  currentPlaylist.forEach((track, index) => {
    const li = document.createElement('li');
    li.textContent = track.name;
    li.className = 'list-group-item';
    li.onclick = () => playTrack(index);
    playlist.appendChild(li);
  });
}

// 3. Play the selected track
function playTrack(index) {
  if (!currentPlaylist[index]) return;

  currentIndex = index;
  const track = currentPlaylist[index];

  player.src = encodeURI(`file://${track.path.replace(/\\/g, '/')}`);
  player.play().catch(err => {
    console.error('Playback error:', err);
  });

  highlightActive(index);
}


const searchInput = document.getElementById('search-input');

searchInput.addEventListener('input', function () {
  const query = this.value.toLowerCase();
  const filteredPlaylist = currentPlaylist.filter(track =>
    track.name.toLowerCase().includes(query)
  );
  renderFilteredPlaylist(filteredPlaylist);
});

function renderFilteredPlaylist(filteredList) {
  playlist.innerHTML = '';

  if (filteredList.length === 0) {
    playlist.innerHTML = '<li class="list-group-item">No matches found.</li>';
    return;
  }

  filteredList.forEach((track, index) => {
    const li = document.createElement('li');
    li.textContent = track.name;
    li.className = 'list-group-item';

    // Map back to the original index in currentPlaylist
    const originalIndex = currentPlaylist.findIndex(t => t.path === track.path);
    li.onclick = () => playTrack(originalIndex);
    playlist.appendChild(li);
  });
}


// 4. Highlight the current track
function highlightActive(index) {
  Array.from(playlist.children).forEach((li, i) => {
    li.classList.toggle('active', i === index);
  });
}

// 5. Play previous track
function playPrevious() {
  if (currentIndex > 0) {
    playTrack(currentIndex - 1);
  }
}

// 6. Play next track
function playNext() {
  if (currentIndex < currentPlaylist.length - 1) {
    playTrack(currentIndex + 1);
  }
}

// 7. Autoplay next song on end
player.addEventListener('ended', playNext);

// 8. Handle file opened directly via "Open with"
window.electronAPI.onFileOpened((filePath) => {
  const safePath = encodeURI(`file://${filePath.replace(/\\/g, '/')}`);
  player.src = safePath;
  player.play().catch(err => {
    console.error('Error playing file:', err);
  });

  // Show as single-item playlist
  const fileName = filePath.split(/[\\/]/).pop();
  playlist.innerHTML = '';
  const li = document.createElement('li');
  li.textContent = fileName;
  li.className = 'list-group-item active';
  playlist.appendChild(li);

  currentPlaylist = [{ name: fileName, path: filePath }];
  currentIndex = 0;

  // Set default cover art when opening a single file
  coverArt.src = 'music.jpg';
});

// 9. Expose functions for buttons in HTML
window.selectFolder = selectFolder;
window.playPrevious = playPrevious;
window.playNext = playNext;
