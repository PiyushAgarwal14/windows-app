const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    icon: path.join(__dirname, 'music.ico'),
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'), // Must exist and be correct
    },
  });

  mainWindow.loadFile('index.html');
}

app.whenReady().then(() => {
  createWindow();

  // IPC handler for folder selection
  ipcMain.handle('select-folder', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory'],
    });

    if (result.canceled || result.filePaths.length === 0) return null;
    return result.filePaths[0];
  });

  
  // IPC handler to read .mp3 files from folder
  ipcMain.handle('get-mp3-files', async (event, folderPath) => {
    try {
      const files = fs.readdirSync(folderPath);
      const mp3Files = files.filter(file => file.toLowerCase().endsWith('.mp3'));

      return mp3Files.map(file => ({
        name: file,
        path: path.join(folderPath, file),
      }));
    } catch (err) {
      console.error('Error reading folder:', err);
      return [];
    }
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
});
