const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const mm = require('music-metadata');  // Import music-metadata

let mainWindow;
let openedFilePath = null;

// Register the open-file event before app is ready
app.on('open-file', (event, filePath) => {
  event.preventDefault();
  if (filePath.toLowerCase().endsWith('.mp3')) {
    openedFilePath = filePath;
    if (mainWindow) {
      mainWindow.webContents.send('open-file', openedFilePath);
    }
  }
});

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    icon: path.join(__dirname, 'music.ico'),
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  mainWindow.loadFile('index.html');

  mainWindow.webContents.on('did-finish-load', () => {
    if (openedFilePath) {
      mainWindow.webContents.send('open-file', openedFilePath);
    }
  });
}

app.whenReady().then(() => {
  const args = process.argv;
  if (args.length >= 2 && args[1].toLowerCase().endsWith('.mp3')) {
    openedFilePath = args[1];
  }

  createWindow();

  ipcMain.handle('select-folder', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory'],
    });

    if (result.canceled || result.filePaths.length === 0) return null;
    return result.filePaths[0];
  });
  

  ipcMain.handle('get-mp3-files', async (event, folderPath) => {
    try {
      const files = fs.readdirSync(folderPath);
      const mp3Files = files.filter(file => file.toLowerCase().endsWith('.mp3'));

      // Extract metadata for each MP3 file
      const mp3FileDetails = await Promise.all(mp3Files.map(async (file) => {
        const fullPath = path.join(folderPath, file);
        let coverDataUrl = null;

        try {
          const metadata = await mm.parseFile(fullPath);
          const picture = metadata.common.picture?.[0];

          if (picture) {
            const base64 = picture.data.toString('base64');
            coverDataUrl = `data:${picture.format};base64,${base64}`;
          }
        } catch (err) {
          console.warn('Error reading metadata:', err);
        }

        return {
          name: file,
          path: fullPath,
          cover: coverDataUrl  // Include cover image data
        };
      }));

      return mp3FileDetails;
    } catch (err) {
      console.error('Error reading folder:', err);
      return [];
    }
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
});
