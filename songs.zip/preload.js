const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  getMp3Files: (folderPath) => ipcRenderer.invoke('get-mp3-files', folderPath)
});
