const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  getMp3Files: (folderPath) => ipcRenderer.invoke('get-mp3-files', folderPath),
  getCoverArt: (filePath) => ipcRenderer.invoke('get-cover-art', filePath),
  onFileOpened: (callback) => ipcRenderer.on('open-file', (event, path) => callback(path))
});
